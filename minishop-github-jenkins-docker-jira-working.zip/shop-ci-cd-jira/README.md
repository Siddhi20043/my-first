# MiniShop: GitHub + Jenkins + Docker + Jira CI/CD Mini-Project

A small shopping-cart demo built with Python standard-library modules only, designed for a beginner DevOps mini-project on Windows. It demonstrates source control, automated Docker builds, automated HTTP tests, and deployment to a local Docker container.

> Demo only: no database, user accounts, real payments, or production security. Do not use the development secret key for a public deployment.

## Project flow

1. Track work in Jira (for example `SHOP-1`).
2. Push code to GitHub.
3. Jenkins checks out the repository and runs the `Jenkinsfile`.
4. Jenkins builds a Docker image.
5. Jenkins runs smoke tests inside that image.
6. Jenkins replaces the local `minishop-demo` container.
7. Open the app at http://localhost:5000.

## Files

- `app.py` — Flask shopping page, cart, demo checkout, and health endpoint
- `tests/test_app.py` — Python unit tests
- `requirements.txt` — documents that no third-party Python packages are needed
- `Dockerfile` — builds the application image
- `Jenkinsfile` — Windows `bat`-based CI/CD pipeline
- `JIRA_SETUP.md` — Jira tracking and integration steps

## A. Install tools on Windows

1. Install Docker Desktop and start it using Linux containers. No separate Python package installation is required to run the app inside Docker.
2. Install Git for Windows.
3. For the simplest setup, install Jenkins on Windows using the official MSI and install a supported Java version (currently Java 21 or later is required by Jenkins). Follow the official Jenkins Windows guide: https://www.jenkins.io/doc/book/installing/windows/
4. During Jenkins setup, install suggested plugins. In **Manage Jenkins → Plugins**, ensure **Pipeline** and **Git** are installed.
5. In PowerShell, confirm:
   ```powershell
   docker --version
   docker info
   git --version
   ```
   Docker must be running before the pipeline can work.

## B. Run the app locally with Docker

From the project folder in PowerShell:
```powershell
docker build -t minishop:local .
docker run --rm -p 5000:5000 --name minishop-local minishop:local
```
Open http://localhost:5000. Stop the app with `Ctrl+C`.

## C. Push to GitHub

1. Create an empty GitHub repository named `minishop-ci-cd` (do not initialize it with a README if you will push this folder).
2. In PowerShell, from this project folder:
   ```powershell
   git init
   git add .
   git commit -m "SHOP-1 Add MiniShop shopping app and CI pipeline"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/minishop-ci-cd.git
   git push -u origin main
   ```
3. Replace `YOUR-USERNAME` with your GitHub username.
4. Use your Jira issue key in commit messages, e.g. `SHOP-2 Add cart tests`. This helps link development activity to Jira when the integration is configured.

## D. Configure Jenkins

### Recommended beginner setup: Jenkins installed directly on Windows

The included Jenkinsfile uses Windows `bat` commands, so use a Windows Jenkins agent with Docker Desktop available in its PATH.

1. Open Jenkins at http://localhost:8080.
2. Choose **New Item → Pipeline** and name it `minishop-ci-cd`.
3. Under **Pipeline**, select **Pipeline script from SCM**.
4. SCM: **Git**. Repository URL: `https://github.com/YOUR-USERNAME/minishop-ci-cd.git`.
5. Branch specifier: `*/main`. Script path: `Jenkinsfile`.
6. If the repository is private, add a GitHub credential in Jenkins and select it here. Never put a password or token in the Jenkinsfile.
7. Save and click **Build Now**.
8. Open **Console Output**. Expected stages: Checkout, Build Docker Image, Test, Deploy Locally.
9. After a successful build, open http://localhost:5000.

Important: Jenkins must run under a Windows account that can execute `docker` commands and connect to Docker Desktop. If Jenkins runs as a Windows service and cannot find Docker, configure a suitable service/agent account or use a dedicated Jenkins agent launched in your logged-in Windows session. Do not grant broad privileges on a production machine.

## E. Jira setup

Follow `JIRA_SETUP.md`. Jira can track the project independently; automated Jenkins-to-Jira build reporting requires a compatible integration and additional configuration. The app and pipeline do not require Jira credentials to build.

## F. Test manually

```powershell
docker run --rm minishop:local python -m unittest discover -s tests -v
```

Or let Jenkins run the pipeline smoke tests. After deployment, verify:
- `http://localhost:5000` — product list
- `http://localhost:5000/health` — should return `{"status":"ok"}`
- Add an item to the cart and try the demo checkout.

## Troubleshooting

- **Docker daemon error:** start Docker Desktop and wait until it says Docker is running.
- **Port 5000 in use:** stop the other process or change the first port in the Jenkinsfile from `5000:5000` to `5001:5000`, then open port 5001.
- **Jenkins cannot find Docker:** run `docker version` under the same Windows account as the Jenkins agent; fix PATH/account permissions.
- **Git checkout fails:** verify repository URL and credentials.
- **Jenkinsfile syntax/build failure:** inspect Console Output and ensure the Jenkins agent is Windows because the pipeline uses `bat`.
- **Jira link not shown:** confirm the Jira integration is installed and configured; using an issue key in a commit message alone does not guarantee a link appears in every Jira setup.

## References

- Jenkins on Windows: https://www.jenkins.io/doc/book/installing/windows/
- Jenkins Pipeline and Docker: https://www.jenkins.io/doc/book/pipeline/docker/
- Jenkins Jira Integration plugin: https://plugins.jenkins.io/jira-integration/
