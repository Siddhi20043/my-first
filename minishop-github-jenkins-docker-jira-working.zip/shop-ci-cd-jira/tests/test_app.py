import http.cookiejar
import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, build_opener, Request

from app import CARTS, create_server


class ShopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server("127.0.0.1", 0)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def setUp(self):
        self.cookies = http.cookiejar.CookieJar()
        self.client = build_opener(HTTPCookieProcessor(self.cookies))
        self.base = f"http://127.0.0.1:{self.port}"

    def test_home_page_shows_products(self):
        with self.client.open(self.base + "/") as response:
            self.assertEqual(response.status, 200)
            self.assertIn(b"Wireless Headphones", response.read())

    def test_health_endpoint(self):
        with self.client.open(self.base + "/health") as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(json.loads(response.read()), {"status": "ok"})

    def test_add_product_to_cart(self):
        request = Request(self.base + "/cart/add/1", data=b"", method="POST")
        with self.client.open(request) as response:
            self.assertEqual(response.status, 200)  # urllib follows redirect
        with self.client.open(self.base + "/cart") as response:
            body = response.read()
            self.assertIn(b"Wireless Headphones", body)

    def test_invalid_product_returns_404(self):
        request = Request(self.base + "/cart/add/999", data=b"", method="POST")
        with self.assertRaises(HTTPError) as error:
            self.client.open(request)
        self.assertEqual(error.exception.code, 404)

    def test_demo_checkout_clears_cart(self):
        add = Request(self.base + "/cart/add/1", data=b"", method="POST")
        self.client.open(add).read()
        checkout = Request(self.base + "/checkout", data=b"", method="POST")
        with self.client.open(checkout) as response:
            self.assertIn(b"Order placed", response.read())
        with self.client.open(self.base + "/cart") as response:
            self.assertIn(b"Your cart is empty", response.read())


if __name__ == "__main__":
    unittest.main()
