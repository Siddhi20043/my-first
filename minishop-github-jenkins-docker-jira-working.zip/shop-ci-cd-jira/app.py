"""MiniShop demo built only with Python's standard library."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from html import escape
import json
import os
import secrets

PRODUCTS = [
    {"id": 1, "name": "Wireless Headphones", "price": 39.99, "description": "Everyday wireless sound"},
    {"id": 2, "name": "Travel Backpack", "price": 29.50, "description": "A lightweight everyday bag"},
    {"id": 3, "name": "Desk Lamp", "price": 18.75, "description": "Warm light for your desk"},
]
CARTS = {}


def money(amount):
    return f"${amount:.2f}"


def page(title, content, cart_count=0, message=""):
    note = f'<p class="notice">{escape(message)}</p>' if message else ""
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{escape(title)} - MiniShop</title>
<style>body{{font-family:Arial,sans-serif;max-width:900px;margin:40px auto;padding:0 18px;color:#20252b}}header{{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #ddd;margin-bottom:24px}}.products{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}}article{{border:1px solid #ddd;border-radius:12px;padding:18px}}button{{background:#1769aa;color:white;border:0;border-radius:6px;padding:9px 13px;cursor:pointer}}a{{color:#1769aa}}.notice{{background:#edf8ee;padding:10px;border-radius:6px}}.muted{{color:#667}}</style></head><body>
<header><h1><a href="/">MiniShop</a></h1><a href="/cart">Cart ({cart_count})</a></header>{note}{content}
<footer class="muted"><p>Demo project for GitHub + Jenkins + Docker + Jira. No real payments or orders.</p></footer></body></html>'''


def product_page(cart_count=0, message=""):
    cards = "".join(
        f'''<article><h3>{escape(p['name'])}</h3><p>{escape(p['description'])}</p><p><strong>{money(p['price'])}</strong></p>
<form method="post" action="/cart/add/{p['id']}"><button type="submit">Add to cart</button></form></article>'''
        for p in PRODUCTS
    )
    return page("Products", f"<h2>Products</h2><div class=\"products\">{cards}</div>", cart_count, message)


class MiniShopHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Keep the demo's Docker/Jenkins logs concise.
        print("%s - %s" % (self.address_string(), fmt % args))

    def get_cart_id(self):
        cookie = self.headers.get("Cookie", "")
        for part in cookie.split(";"):
            key, sep, value = part.strip().partition("=")
            if sep and key == "minishop_cart":
                return value
        return None

    def get_cart(self, create=False):
        cart_id = self.get_cart_id()
        is_new = not cart_id or cart_id not in CARTS
        if is_new and create:
            cart_id = secrets.token_hex(12)
            CARTS[cart_id] = []
        elif is_new:
            return None, []
        return cart_id, CARTS.setdefault(cart_id, [])

    def send_body(self, status, body, content_type="text/html; charset=utf-8", extra_headers=None):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location, cart_id=None):
        headers = {"Location": location}
        if cart_id:
            headers["Set-Cookie"] = f"minishop_cart={cart_id}; Path=/; HttpOnly; SameSite=Lax"
        self.send_body(303, "", extra_headers=headers)

    def do_GET(self):
        parsed = urlparse(self.path)
        cart_id, cart = self.get_cart()
        if parsed.path == "/health":
            return self.send_body(200, json.dumps({"status": "ok"}), "application/json; charset=utf-8")
        if parsed.path == "/":
            return self.send_body(200, product_page(len(cart)))
        if parsed.path == "/cart":
            items = [p for item_id in cart for p in PRODUCTS if p["id"] == item_id]
            if items:
                rows = "".join(f'''<li>{escape(item['name'])} — {money(item['price'])}
<form style="display:inline" method="post" action="/cart/remove/{item['id']}"><button type="submit">Remove</button></form></li>''' for item in items)
                total = sum(item["price"] for item in items)
                content = f'''<h2>Your cart</h2><ul>{rows}</ul><p><strong>Total: {money(total)}</strong></p>
<form method="post" action="/checkout"><button type="submit">Place demo order</button></form><p><a href="/">Continue shopping</a></p>'''
            else:
                content = '<h2>Your cart</h2><p>Your cart is empty.</p><p><a href="/">Continue shopping</a></p>'
            return self.send_body(200, page("Your cart", content, len(cart)))
        return self.send_body(404, "Not found", "text/plain; charset=utf-8")

    def do_POST(self):
        path = urlparse(self.path).path
        if path.startswith("/cart/add/"):
            try:
                product_id = int(path.rsplit("/", 1)[1])
            except ValueError:
                return self.send_body(400, "Invalid product id", "text/plain; charset=utf-8")
            if not any(p["id"] == product_id for p in PRODUCTS):
                return self.send_body(404, "Product not found", "text/plain; charset=utf-8")
            cart_id, cart = self.get_cart(create=True)
            cart.append(product_id)
            return self.redirect("/", cart_id)
        if path.startswith("/cart/remove/"):
            try:
                product_id = int(path.rsplit("/", 1)[1])
            except ValueError:
                return self.send_body(400, "Invalid product id", "text/plain; charset=utf-8")
            cart_id, cart = self.get_cart()
            if product_id in cart:
                cart.remove(product_id)
            return self.redirect("/cart", cart_id)
        if path == "/checkout":
            cart_id, cart = self.get_cart()
            if not cart:
                return self.redirect("/cart", cart_id)
            cart.clear()
            content = '<h2>Order placed!</h2><p>This is a demo checkout; no payment was taken.</p><p><a href="/">Back to products</a></p>'
            return self.send_body(200, page("Order placed", content, 0, "Demo order completed."))
        return self.send_body(404, "Not found", "text/plain; charset=utf-8")


def create_server(host="0.0.0.0", port=5000):
    return ThreadingHTTPServer((host, port), MiniShopHandler)


if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    server = create_server(host, port)
    print(f"MiniShop running on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
