# Jira setup for MiniShop

There are two levels of Jira use. Start with manual issue tracking; add automatic Jenkins reporting only if your Jira administrator and plan support it.

## 1. Create a Jira project and issues

1. Sign in to your Jira Cloud site.
2. Create a project named **MiniShop CI/CD**. A Scrum or Kanban project is fine.
3. Create these sample issues (the project key may differ from `SHOP`):
   - `SHOP-1` — Create MiniShop application
   - `SHOP-2` — Add Dockerfile and containerize the app
   - `SHOP-3` — Configure Jenkins pipeline
   - `SHOP-4` — Run tests and deploy container
4. If Jira assigns another key, use the actual key in Git commit messages.

## 2. Link GitHub development activity

- In commits and pull request titles, include the issue key, for example:
  `SHOP-2 Add Dockerfile and pipeline`
- If available for your Jira plan, install/configure the GitHub for Jira app from Atlassian Marketplace and connect the GitHub organization/repository to the Jira site.
- Confirm your commit or pull request appears on the Jira issue's development panel.

## 3. Connect Jenkins and Jira (optional automated build reporting)

Jenkins-to-Jira integrations vary by Jira Cloud vs Data Center, app availability, and organization permissions. Check the current compatibility and licensing before proceeding.

1. In Jenkins, open **Manage Jenkins → Plugins** and search for **Jira Integration**. Install only the plugin compatible with your Jira deployment.
2. Follow the plugin's current setup instructions: https://plugins.jenkins.io/jira-integration/
3. Jira Cloud may require an administrator to install/configure the **Jenkins for Jira** app in Jira. This app may not be free; verify the current listing and permissions.
4. Configure the Jira site URL and the required authentication/connection method in the plugin/app UI. Use a dedicated token or credential stored in Jenkins Credentials; never commit secrets into Git.
5. Run a build associated with a Jira issue key and verify the expected build/deployment details appear in Jira.

## Important notes

- A Jira issue board does not automatically trigger Jenkins by itself in this sample.
- GitHub can trigger Jenkins using a webhook, but for a first local demo, use **Build Now**. A webhook to `localhost` cannot be reached by GitHub; automatic webhook builds require a reachable Jenkins URL or a secure tunnel.
- Jira Cloud, Jira Data Center, app licensing, and company security rules can change the exact steps. Use the official current plugin guide linked above.
